public class Photo {
	protected String id;
	protected String nom;
	protected String url;
	protected Boutique boutique;
	protected Produit produit;

	public Photo(String id, String nom, String url, Boutique boutique, Produit produit) {
		this.id = id;
		this.nom = nom;
		this.url = url;
		this.boutique = boutique;
		this.produit = produit;
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getNom() {
		return this.nom;
	}

	public String setNom(String nom) {
		this.nom = nom;
		return this.nom;
	}

	public String getUrl() {
		return this.url;
	}

	public String setUrl(String url) {
		this.url = url;
		return this.url;
	}

	public Boutique getBoutique() {
		return this.boutique;
	}

	public Boutique setBoutique(Boutique boutique) {
		this.boutique = boutique;
		return this.boutique;
	}

	public Produit getProduit() {
		return this.produit;
	}

	public Produit setProduit(Produit produit) {
		this.produit = produit;
		return this.produit;
	}
}
