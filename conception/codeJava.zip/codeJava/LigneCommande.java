public class LigneCommande {
	protected String id;
	protected String quantite;
	protected Commande commande;
	protected Produit produit;

	public LigneCommande(String id, String quantite, Commande commande, Produit produit) {
		this.id = id;
		this.quantite = quantite;
		this.commande = commande;
		this.produit = produit;
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getQuantite() {
		return this.quantite;
	}

	public String setQuantite(String quantite) {
		this.quantite = quantite;
		return this.quantite;
	}

	public Commande getCommande() {
		return this.commande;
	}

	public Commande setCommande(Commande commande) {
		this.commande = commande;
		return this.commande;
	}

	public Produit getProduit() {
		return this.produit;
	}

	public Produit setProduit(Produit produit) {
		this.produit = produit;
		return this.produit;
	}
}
