import java.util.ArrayList;

public class Adresse {
	protected String id;
	protected String rue;
	protected String numero;
	protected String numeroAppartement;
	protected String message;
	protected String code;
	protected String ville;
	protected Utilisateur utilisateur;
	protected ArrayList<Livraison> livraisons;

	public Adresse(String id, String rue, String numero, String numeroAppartement, String message, String code, String ville, Utilisateur utilisateur) {
		this.id = id;
		this.rue = rue;
		this.numero = numero;
		this.numeroAppartement = numeroAppartement;
		this.message = message;
		this.code = code;
		this.ville = ville;
		this.utilisateur = utilisateur;
		this.livraisons = new ArrayList<Livraison>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getRue() {
		return this.rue;
	}

	public String setRue(String rue) {
		this.rue = rue;
		return this.rue;
	}

	public String getNumero() {
		return this.numero;
	}

	public String setNumero(String numero) {
		this.numero = numero;
		return this.numero;
	}

	public String getNumeroAppartement() {
		return this.numeroAppartement;
	}

	public String setNumeroAppartement(String numeroAppartement) {
		this.numeroAppartement = numeroAppartement;
		return this.numeroAppartement;
	}

	public String getMessage() {
		return this.message;
	}

	public String setMessage(String message) {
		this.message = message;
		return this.message;
	}

	public String getCode() {
		return this.code;
	}

	public String setCode(String code) {
		this.code = code;
		return this.code;
	}

	public String getVille() {
		return this.ville;
	}

	public String setVille(String ville) {
		this.ville = ville;
		return this.ville;
	}

	public Utilisateur getUtilisateur() {
		return this.utilisateur;
	}

	public Utilisateur setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
		return this.utilisateur;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Livraison> getLivraisons() {
		return (ArrayList<Livraison>) this.livraisons.clone();
	}

	public Adresse addLivraison(Livraison item) {
		this.livraisons.add(item);
		return this;
	}

	public Adresse removeLivraison(Livraison item) {
		this.livraisons.remove(item);
		return this;
	}
}
