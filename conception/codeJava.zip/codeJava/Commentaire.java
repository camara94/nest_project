public class Commentaire {
	protected String id;
	protected String titre;
	protected String contenu;
	protected String creerLe;
	protected Boutique boutique;
	protected Utilisateur utilisateur;

	public Commentaire(String id, String titre, String contenu, String creerLe, Boutique boutique, Utilisateur utilisateur) {
		this.id = id;
		this.titre = titre;
		this.contenu = contenu;
		this.creerLe = creerLe;
		this.boutique = boutique;
		this.utilisateur = utilisateur;
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getTitre() {
		return this.titre;
	}

	public String setTitre(String titre) {
		this.titre = titre;
		return this.titre;
	}

	public String getContenu() {
		return this.contenu;
	}

	public String setContenu(String contenu) {
		this.contenu = contenu;
		return this.contenu;
	}

	public String getCreerLe() {
		return this.creerLe;
	}

	public String setCreerLe(String creerLe) {
		this.creerLe = creerLe;
		return this.creerLe;
	}

	public Boutique getBoutique() {
		return this.boutique;
	}

	public Boutique setBoutique(Boutique boutique) {
		this.boutique = boutique;
		return this.boutique;
	}

	public Utilisateur getUtilisateur() {
		return this.utilisateur;
	}

	public Utilisateur setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
		return this.utilisateur;
	}
}
