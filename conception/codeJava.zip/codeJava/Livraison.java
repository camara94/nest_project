public class Livraison {
	protected String date;
	protected String ;
	protected Commande commande;
	protected Adresse adresse;

	public Livraison(String date, String , Commande commande, Adresse adresse) {
		this.date = date;
		this. = ;
		this.commande = commande;
		this.adresse = adresse;
	}

	public String getDate() {
		return this.date;
	}

	public String setDate(String date) {
		this.date = date;
		return this.date;
	}

	public String get() {
		return this.;
	}

	public String set(String ) {
		this. = ;
		return this.;
	}

	public Commande getCommande() {
		return this.commande;
	}

	public Commande setCommande(Commande commande) {
		this.commande = commande;
		return this.commande;
	}

	public Adresse getAdresse() {
		return this.adresse;
	}

	public Adresse setAdresse(Adresse adresse) {
		this.adresse = adresse;
		return this.adresse;
	}
}
