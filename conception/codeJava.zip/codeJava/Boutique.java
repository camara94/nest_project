import java.util.ArrayList;

public class Boutique {
	protected String id;
	protected String nom;
	protected String rue;
	protected String numero;
	protected String codePays;
	protected String telephone;
	protected ArrayList<Commentaire> commentaires;
	protected ArrayList<Photo> photos;
	protected ArrayList<Produit> produits;

	public Boutique(String id, String nom, String rue, String numero, String codePays, String telephone) {
		this.id = id;
		this.nom = nom;
		this.rue = rue;
		this.numero = numero;
		this.codePays = codePays;
		this.telephone = telephone;
		this.commentaires = new ArrayList<Commentaire>();
		this.photos = new ArrayList<Photo>();
		this.produits = new ArrayList<Produit>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getNom() {
		return this.nom;
	}

	public String setNom(String nom) {
		this.nom = nom;
		return this.nom;
	}

	public String getRue() {
		return this.rue;
	}

	public String setRue(String rue) {
		this.rue = rue;
		return this.rue;
	}

	public String getNumero() {
		return this.numero;
	}

	public String setNumero(String numero) {
		this.numero = numero;
		return this.numero;
	}

	public String getCodePays() {
		return this.codePays;
	}

	public String setCodePays(String codePays) {
		this.codePays = codePays;
		return this.codePays;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public String setTelephone(String telephone) {
		this.telephone = telephone;
		return this.telephone;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Commentaire> getCommentaires() {
		return (ArrayList<Commentaire>) this.commentaires.clone();
	}

	public Boutique addCommentaire(Commentaire item) {
		this.commentaires.add(item);
		return this;
	}

	public Boutique removeCommentaire(Commentaire item) {
		this.commentaires.remove(item);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Photo> getPhotos() {
		return (ArrayList<Photo>) this.photos.clone();
	}

	public Boutique addPhoto(Photo item) {
		this.photos.add(item);
		return this;
	}

	public Boutique removePhoto(Photo item) {
		this.photos.remove(item);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Produit> getProduits() {
		return (ArrayList<Produit>) this.produits.clone();
	}

	public Boutique addProduit(Produit item) {
		this.produits.add(item);
		return this;
	}

	public Boutique removeProduit(Produit item) {
		this.produits.remove(item);
		return this;
	}
}
