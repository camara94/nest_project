import java.util.ArrayList;

public class Utilisateur {
	protected String id;
	protected String prenom;
	protected String nom;
	protected String password;
	protected String email;
	protected String genre;
	protected String telephone;
	protected ArrayList<Commentaire> commentaires;
	protected ArrayList<Commande> commandes;
	protected ArrayList<Adresse> adresses;

	public Utilisateur(String id, String prenom, String nom, String password, String email, String genre, String telephone) {
		this.id = id;
		this.prenom = prenom;
		this.nom = nom;
		this.password = password;
		this.email = email;
		this.genre = genre;
		this.telephone = telephone;
		this.commentaires = new ArrayList<Commentaire>();
		this.commandes = new ArrayList<Commande>();
		this.adresses = new ArrayList<Adresse>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getPrenom() {
		return this.prenom;
	}

	public String setPrenom(String prenom) {
		this.prenom = prenom;
		return this.prenom;
	}

	public String getNom() {
		return this.nom;
	}

	public String setNom(String nom) {
		this.nom = nom;
		return this.nom;
	}

	public String getPassword() {
		return this.password;
	}

	public String setPassword(String password) {
		this.password = password;
		return this.password;
	}

	public String getEmail() {
		return this.email;
	}

	public String setEmail(String email) {
		this.email = email;
		return this.email;
	}

	public String getGenre() {
		return this.genre;
	}

	public String setGenre(String genre) {
		this.genre = genre;
		return this.genre;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public String setTelephone(String telephone) {
		this.telephone = telephone;
		return this.telephone;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Commentaire> getCommentaires() {
		return (ArrayList<Commentaire>) this.commentaires.clone();
	}

	public Utilisateur addCommentaire(Commentaire item) {
		this.commentaires.add(item);
		return this;
	}

	public Utilisateur removeCommentaire(Commentaire item) {
		this.commentaires.remove(item);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Commande> getCommandes() {
		return (ArrayList<Commande>) this.commandes.clone();
	}

	public Utilisateur addCommande(Commande item) {
		this.commandes.add(item);
		return this;
	}

	public Utilisateur removeCommande(Commande item) {
		this.commandes.remove(item);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Adresse> getAdresses() {
		return (ArrayList<Adresse>) this.adresses.clone();
	}

	public Utilisateur addAdresse(Adresse item) {
		this.adresses.add(item);
		return this;
	}

	public Utilisateur removeAdresse(Adresse item) {
		this.adresses.remove(item);
		return this;
	}
}
