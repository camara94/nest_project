import java.util.ArrayList;

public class Commande {
	protected String id;
	protected String creeLe;
	protected String status;
	protected Utilisateur utilisateur;
	protected Livraison livraison;
	protected ArrayList<LigneCommande> ligneCommandes;

	public Commande(String id, String creeLe, String status, Utilisateur utilisateur, Livraison livraison) {
		this.id = id;
		this.creeLe = creeLe;
		this.status = status;
		this.utilisateur = utilisateur;
		this.livraison = livraison;
		this.ligneCommandes = new ArrayList<LigneCommande>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getCreeLe() {
		return this.creeLe;
	}

	public String setCreeLe(String creeLe) {
		this.creeLe = creeLe;
		return this.creeLe;
	}

	public String getStatus() {
		return this.status;
	}

	public String setStatus(String status) {
		this.status = status;
		return this.status;
	}

	public Utilisateur getUtilisateur() {
		return this.utilisateur;
	}

	public Utilisateur setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
		return this.utilisateur;
	}

	public Livraison getLivraison() {
		return this.livraison;
	}

	public Livraison setLivraison(Livraison livraison) {
		this.livraison = livraison;
		return this.livraison;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<LigneCommande> getLigneCommandes() {
		return (ArrayList<LigneCommande>) this.ligneCommandes.clone();
	}

	public Commande addLigneCommande(LigneCommande item) {
		this.ligneCommandes.add(item);
		return this;
	}

	public Commande removeLigneCommande(LigneCommande item) {
		this.ligneCommandes.remove(item);
		return this;
	}
}
