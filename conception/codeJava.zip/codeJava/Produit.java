import java.util.ArrayList;

public class Produit {
	protected String id;
	protected String designation;
	protected String description;
	protected String prix;
	protected Boutique boutique;
	protected ArrayList<Photo> photos;
	protected ArrayList<LigneCommande> ligneCommandes;
	protected Categorie categorie;

	public Produit(String id, String designation, String description, String prix, Boutique boutique, Categorie categorie) {
		this.id = id;
		this.designation = designation;
		this.description = description;
		this.prix = prix;
		this.boutique = boutique;
		this.categorie = categorie;
		this.photos = new ArrayList<Photo>();
		this.ligneCommandes = new ArrayList<LigneCommande>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getDesignation() {
		return this.designation;
	}

	public String setDesignation(String designation) {
		this.designation = designation;
		return this.designation;
	}

	public String getDescription() {
		return this.description;
	}

	public String setDescription(String description) {
		this.description = description;
		return this.description;
	}

	public String getPrix() {
		return this.prix;
	}

	public String setPrix(String prix) {
		this.prix = prix;
		return this.prix;
	}

	public Boutique getBoutique() {
		return this.boutique;
	}

	public Boutique setBoutique(Boutique boutique) {
		this.boutique = boutique;
		return this.boutique;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Photo> getPhotos() {
		return (ArrayList<Photo>) this.photos.clone();
	}

	public Produit addPhoto(Photo item) {
		this.photos.add(item);
		return this;
	}

	public Produit removePhoto(Photo item) {
		this.photos.remove(item);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<LigneCommande> getLigneCommandes() {
		return (ArrayList<LigneCommande>) this.ligneCommandes.clone();
	}

	public Produit addLigneCommande(LigneCommande item) {
		this.ligneCommandes.add(item);
		return this;
	}

	public Produit removeLigneCommande(LigneCommande item) {
		this.ligneCommandes.remove(item);
		return this;
	}

	public Categorie getCategorie() {
		return this.categorie;
	}

	public Categorie setCategorie(Categorie categorie) {
		this.categorie = categorie;
		return this.categorie;
	}
}
