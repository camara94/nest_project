import java.util.ArrayList;

public class Categorie {
	protected String id;
	protected String nom;
	protected ArrayList<Produit> produits;

	public Categorie(String id, String nom) {
		this.id = id;
		this.nom = nom;
		this.produits = new ArrayList<Produit>();
	}

	public String getId() {
		return this.id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public String getNom() {
		return this.nom;
	}

	public String setNom(String nom) {
		this.nom = nom;
		return this.nom;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Produit> getProduits() {
		return (ArrayList<Produit>) this.produits.clone();
	}

	public Categorie addProduit(Produit item) {
		this.produits.add(item);
		return this;
	}

	public Categorie removeProduit(Produit item) {
		this.produits.remove(item);
		return this;
	}
}
